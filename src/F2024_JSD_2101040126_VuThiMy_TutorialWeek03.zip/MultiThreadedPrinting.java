class PrintLetterTask implements Runnable {
    private char letter;
    private int times;

    public PrintLetterTask(char letter, int times) {
        this.letter = letter;
        this.times = times;
    }

    @Override
    public void run() {
        for (int i = 0; i < times; i++) {
            System.out.print(letter);
        }
    }
}

class PrintNumbersTask implements Runnable {
    private int start;
    private int end;

    public PrintNumbersTask(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public void run() {
        for (int i = start; i <= end; i++) {
            System.out.print(i + " ");
        }
    }
}

public class MultiThreadedPrinting {
    public static void main(String[] args) {
        // Create tasks
        Runnable task1 = new PrintLetterTask('F', 50); // Prints 'F' 50 times
        Runnable task2 = new PrintLetterTask('I', 50); // Prints 'I' 50 times
        Runnable task3 = new PrintLetterTask('T', 50); // Prints 'T' 50 times
        Runnable task4 = new PrintNumbersTask(1, 100); // Prints numbers from 1 to 100

        // Create threads for each task
        Thread thread1 = new Thread(task1);
        Thread thread2 = new Thread(task2);
        Thread thread3 = new Thread(task3);
        Thread thread4 = new Thread(task4);

        // Start the threads
        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();
    }
}
