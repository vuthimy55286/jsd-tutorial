import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class FileSearchTask implements Runnable {
    private File file;
    private String keyword;

    public FileSearchTask(File file, String keyword) {
        this.file = file;
        this.keyword = keyword;
    }

    @Override
    public void run() {
        try (Scanner scanner = new Scanner(file)) {
            int lineNumber = 0;
            boolean found = false;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lineNumber++;
                if (line.contains(keyword)) {
                    System.out.printf("Keyword '%s' found in file '%s' at line %d: %s%n", keyword, file.getName(), lineNumber, line);
                    found = true;
                }
            }
            if (!found) {
                System.out.printf("Keyword '%s' not found in file '%s'.%n", keyword, file.getName());
            }
        } catch (FileNotFoundException e) {
            System.err.printf("File '%s' not found or cannot be read.%n", file.getName());
        }
    }
}

public class MultiThreadedFileSearch {
    public static void main(String[] args) {
        String directoryPath = "path/to/your/directory";  // Replace with your directory path
        String keyword = "yourKeyword";                   // Replace with the keyword you're searching for

        // List all files in the directory
        File folder = new File(directoryPath);
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt")); // Filter for text files or any specific type

        if (files == null || files.length == 0) {
            System.out.println("No files found in the directory.");
            return;
        }

        // Create a list to hold threads
        List<Thread> threads = new ArrayList<>();

        // Create and start a thread for each file
        for (File file : files) {
            Thread thread = new Thread(new FileSearchTask(file, keyword));
            threads.add(thread);
            thread.start();
        }

        // Wait for all threads to complete
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Search completed.");
    }
}

