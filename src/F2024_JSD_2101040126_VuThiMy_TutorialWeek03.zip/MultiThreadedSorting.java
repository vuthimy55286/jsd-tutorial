import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class SortTask implements Runnable {
    private int[] array;
    private String algorithm;

    public SortTask(int[] array, String algorithm) {
        this.array = array.clone(); // Clone to avoid shared modifications
        this.algorithm = algorithm;
    }

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        System.out.println(algorithm + " start time: " + startTime + " ms");

        switch (algorithm) {
            case "Selection Sort":
                selectionSort(array);
                break;
            case "Insertion Sort":
                insertionSort(array);
                break;
            case "Bubble Sort":
                bubbleSort(array);
                break;
        }

        long endTime = System.currentTimeMillis();
        System.out.println(algorithm + " end time: " + endTime + " ms");
        System.out.println(algorithm + " duration: " + (endTime - startTime) + " ms");
        System.out.println(algorithm + " final sorted array: " + Arrays.toString(array));
    }

    private void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;

            pauseAndPrint(arr);
        }
    }

    private void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;

            pauseAndPrint(arr);
        }
    }

    private void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }

            pauseAndPrint(arr);
        }
    }

    private void pauseAndPrint(int[] arr) {
        try {
            Thread.sleep(500); // Pause for 0.5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(algorithm + " current array: " + Arrays.toString(arr));
    }
}

public class MultiThreadedSorting {
    public static void main(String[] args) {
        // Create an array from 1 to 50
        Integer[] array = new Integer[50];
        for (int i = 0; i < 50; i++) {
            array[i] = i + 1;
        }

        // Shuffle the array randomly
        List<Integer> list = Arrays.asList(array);
        Collections.shuffle(list);
        list.toArray(array);

        // Convert to primitive int array
        int[] intArray = Arrays.stream(array).mapToInt(Integer::intValue).toArray();

        // Create sorting tasks
        Runnable selectionSortTask = new SortTask(intArray, "Selection Sort");
        Runnable insertionSortTask = new SortTask(intArray, "Insertion Sort");
        Runnable bubbleSortTask = new SortTask(intArray, "Bubble Sort");

        // Create threads for each sorting task
        Thread thread1 = new Thread(selectionSortTask);
        Thread thread2 = new Thread(insertionSortTask);
        Thread thread3 = new Thread(bubbleSortTask);

        // Start the threads
        thread1.start();
        thread2.start();
        thread3.start();

        // Wait for all threads to complete
        try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Print the number of available processors
        int processors = Runtime.getRuntime().availableProcessors();
        System.out.println("Number of available processors: " + processors);
    }
}
