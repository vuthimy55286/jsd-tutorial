package tut04.tanks;

public abstract class TankFunction {
    public abstract void move() throws Exception;
    public abstract void shoot(Tank tank);
}
