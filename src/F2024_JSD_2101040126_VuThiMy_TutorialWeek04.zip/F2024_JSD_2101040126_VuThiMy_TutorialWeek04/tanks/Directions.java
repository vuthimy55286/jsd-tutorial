package tut04.tanks;

public enum Directions {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
