package tut04.powerups;

import tut04.tanks.point2D;

public class SpeedBoost extends Powerup {
    public SpeedBoost(point2D point2D) {
        super();
    }
}
