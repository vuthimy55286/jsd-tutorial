package F2024_JSD_2101040126_VuThiMy_TutorialWeek04.powerups.F2024_JSD_2101040126_VuThiMy_TutorialWeek04.powerups;

import F2024_JSD_2101040126_VuThiMy_TutorialWeek04.powerups.F2024_JSD_2101040126_VuThiMy_TutorialWeek04.tanks.EnemyTank;

public class Timer {
    private EnemyTank enemyTanks;
    public Timer(){
        this.enemyTanks = enemyTanks;
    }
    public void activate(){
        enemyTanks.setPosition(enemyTanks.getPosition());
    }
}
