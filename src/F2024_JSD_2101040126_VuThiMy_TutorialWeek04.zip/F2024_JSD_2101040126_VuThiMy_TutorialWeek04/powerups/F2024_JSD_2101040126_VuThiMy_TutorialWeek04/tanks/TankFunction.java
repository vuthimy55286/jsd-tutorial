package F2024_JSD_2101040126_VuThiMy_TutorialWeek04.powerups.F2024_JSD_2101040126_VuThiMy_TutorialWeek04.tanks;

public abstract class TankFunction {
    public abstract void move() throws Exception;
    public abstract void shoot(Tank tank);
}
