package tut04.powerups;

import java.util.List;
import tut04.tanks.point2D;
import tut04.tanks.Tank;


public class Shovel extends Powerup{
    public Shovel(point2D position) {
        super(position);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void applyEffectToTank(Tank playerTank) {
        // TODO Auto-generated method stub

    }

    @Override
    public void applyEffect() {
        // TODO Auto-generated method stub

    }

    @Override
    public void applyEffectToEnemies(List<Tank> enemies) {
        // TODO Auto-generated method stub

    }

}
